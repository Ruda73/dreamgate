"""
dreamgate/gate.py — The DreamGate state machine.

Gate fires on h(s) alone — anomaly detection.
Clock advances on h²·X_gen — learning measurement.
These are independent. Neither depends on the other.

    NORMAL : h < tau_low              — prior confirmed
    HOLD   : h >= tau_low, brief      — anomaly, watching
    DREAM  : h >= tau_low, sustained  — hypothesis warranted

Reference: van Rensburg (2026).
"""

from dataclasses import dataclass
from typing import Optional, Callable
from .core import gamma, surprisal, epsilon_Q, helstrom, XgenEstimator, clock_tick

NORMAL = "NORMAL"
HOLD   = "HOLD"
DREAM  = "DREAM"


@dataclass
class GateConfig:
    """
    sigma      : match to typical prediction error in your signal.
                 Rule of thumb: sigma ≈ std(signal) * 0.2 for well-fitted predictor.
    tau_low    : h(bits) threshold for HOLD entry. 
                 At tau_low=1.5: fires when err > 1.45σ.
                 At tau_low=2.0: fires when err > 1.67σ.
    dream_sustain : consecutive HOLD ticks before DREAM.
    hysteresis : fraction of tau_low for NORMAL return (prevents oscillation).
    clock_scale: Δτ scale factor — tune to your application's time units.
    """
    sigma:         float = 0.5
    tau_low:       float = 1.5    # bits — gate threshold
    dream_sustain: int   = 8      # ticks
    hysteresis:    float = 0.5    # fraction of tau_low
    alpha_fast:    float = 0.15
    alpha_slow:    float = 0.02
    clock_scale:   float = 0.01


@dataclass
class GateResult:
    actual:    float
    predicted: float
    err:       float
    gamma:     float
    h:         float
    epsilon_Q: float
    P_err:     float
    X_gen:     float
    X_mem:     float
    gap:       float
    regime:    str
    delta_tau: float
    clock:     float
    state:     str
    sustain:   int


class DreamGate:
    """
    The DreamGate.

        gate  = DreamGate()
        result = gate.tick(value)
        if result.state == DREAM:
            act(result)
    """

    def __init__(self,
                 config:   Optional[GateConfig] = None,
                 on_dream: Optional[Callable[[GateResult], None]] = None):
        self.cfg      = config or GateConfig()
        self.on_dream = on_dream
        self._xgen    = XgenEstimator(self.cfg.alpha_fast, self.cfg.alpha_slow)
        self._pred:   Optional[float] = None
        self._state   = NORMAL
        self._sustain = 0
        self._clock   = 0.0
        self._n       = 0

    def tick(self, actual: float,
             held_out: Optional[float] = None) -> GateResult:
        cfg  = self.cfg
        pred = actual if self._pred is None else self._pred

        # Update EWMA predictor
        self._pred = cfg.alpha_fast * actual + (1.0 - cfg.alpha_fast) * pred

        err = abs(actual - pred)
        g   = gamma(err, cfg.sigma)
        h   = surprisal(err, cfg.sigma)
        eQ  = epsilon_Q(g)
        pe  = helstrom(g)

        # X_gen: held_out defaults to actual (single-channel, X_gen unreliable)
        h_held = surprisal(abs((held_out if held_out is not None else actual) - pred),
                          cfg.sigma)
        lr = self._xgen.update(h, h_held)

        # Clock — independent of gate state
        dt          = clock_tick(h, lr["X_gen"], cfg.clock_scale)
        self._clock += dt
        self._n     += 1

        # Gate — on h alone
        self._state, self._sustain = self._step(h)

        r = GateResult(
            actual=actual, predicted=pred, err=err,
            gamma=g, h=h, epsilon_Q=eQ, P_err=pe,
            X_gen=lr["X_gen"], X_mem=lr["X_mem"],
            gap=lr["gap"], regime=lr["regime"],
            delta_tau=dt, clock=self._clock,
            state=self._state, sustain=self._sustain,
        )
        if self._state == DREAM and self.on_dream:
            self.on_dream(r)
        return r

    def reset(self):
        self._xgen.reset()
        self._pred    = None
        self._state   = NORMAL
        self._sustain = 0
        self._clock   = 0.0
        self._n       = 0

    @property
    def state(self):  return self._state
    @property
    def clock(self):  return self._clock

    def _step(self, h: float):
        cfg  = self.cfg
        s    = self._state
        sus  = self._sustain
        hi   = h >= cfg.tau_low
        lo   = h <  cfg.tau_low * cfg.hysteresis

        if s == NORMAL:
            return (HOLD, 1) if hi else (NORMAL, 0)
        if s == HOLD:
            if hi:
                sus += 1
                return (DREAM, sus) if sus >= cfg.dream_sustain else (HOLD, sus)
            return (NORMAL, 0) if lo else (HOLD, sus)
        if s == DREAM:
            return (NORMAL, 0) if lo else (DREAM, sus + 1)
        return (NORMAL, 0)
