"""
dreamgate/config.py — Default configurations per vertical.

Pre-calibrated GateConfig instances for common signal domains.
Adjust sigma to match your signal's standard deviation.
"""

from .gate import GateConfig


# Industrial sensor — slow-moving, low noise
# err > 1.5σ triggers HOLD; sustained 10 ticks → DREAM
INDUSTRIAL = GateConfig(
    sigma=0.5, tau_low=2.0, dream_sustain=10,
    hysteresis=0.4, clock_scale=0.01
)

# EdTech response time — faster signal, more tolerance for spikes
EDTECH = GateConfig(
    sigma=0.5, tau_low=1.5, dream_sustain=6,
    hysteresis=0.5, clock_scale=0.05
)

# Security / authentication — low tolerance, fast response
SECURITY = GateConfig(
    sigma=0.5, tau_low=1.2, dream_sustain=5,
    hysteresis=0.4, clock_scale=0.01
)

# Gaming / flow state — moderate sensitivity
GAMING = GateConfig(
    sigma=0.5, tau_low=1.5, dream_sustain=8,
    hysteresis=0.5, clock_scale=0.02
)
