"""
tests/test_gate.py — One test per behavioural claim.
"""

import math
import random
import pytest
import sys
sys.path.insert(0, '..')

from dreamgate.gate import DreamGate, GateConfig, GateResult, NORMAL, HOLD, DREAM

CFG = GateConfig(sigma=0.5, tau_low=1.5, dream_sustain=8, hysteresis=0.5)


def stable_signal(n=200, seed=42):
    random.seed(seed)
    return [math.sin(i*0.1)*0.3 + random.gauss(0, 0.05) for i in range(n)]


def burst_signal(warmup=40, burst_len=80, seed=42):
    """Unpredictable: large random-phase sine keeps err high."""
    random.seed(seed)
    pre  = [math.sin(i*0.1)*0.3 + random.gauss(0, 0.05) for i in range(warmup)]
    post = [math.sin(i*2.3 + random.gauss(0, 1.5))*2.5 + random.gauss(0, 0.4)
            for i in range(burst_len)]
    return pre + post


def sustained_anomaly(n=60, seed=99):
    """Random walk long enough that DREAM is reliably reached."""
    random.seed(seed)
    v, out = 0.0, []
    for _ in range(n):
        v += random.gauss(0, 1.5)
        out.append(v)
    return out


# ── Stable signal ─────────────────────────────────────────────────────────────

def test_stable_signal_stays_mostly_normal():
    gate = DreamGate(config=CFG)
    states = [gate.tick(v).state for v in stable_signal()]
    frac = states.count(NORMAL) / len(states)
    assert frac >= 0.90, f"Expected >=90% NORMAL, got {frac:.1%}"

def test_stable_signal_clock_near_zero():
    gate = DreamGate(config=CFG)
    for v in stable_signal():
        gate.tick(v)
    assert gate.clock < 0.5


# ── Burst signal ──────────────────────────────────────────────────────────────

def test_burst_reaches_hold():
    gate = DreamGate(config=CFG)
    states = [gate.tick(v).state for v in burst_signal()]
    assert HOLD in states

def test_burst_reaches_dream():
    gate = DreamGate(config=CFG)
    states = [gate.tick(v).state for v in burst_signal()]
    assert DREAM in states

def test_clock_never_decreases():
    """The only hard invariant on the clock."""
    gate = DreamGate(config=CFG)
    prev = 0.0
    for v in stable_signal(n=100) + burst_signal():
        r = gate.tick(v)
        assert r.clock >= prev - 1e-12
        prev = r.clock


# ── State transitions ─────────────────────────────────────────────────────────

def test_normal_to_hold_on_unpredictable_signal():
    gate = DreamGate(config=CFG)
    for v in stable_signal(n=50):
        gate.tick(v)
    assert gate.state == NORMAL
    # Alternating extremes — predictor cannot track
    states = [gate.tick(v).state for v in [5.0, -5.0, 5.0, -5.0]]
    assert any(s in (HOLD, DREAM) for s in states)

def test_dream_reached_on_sustained_anomaly():
    """With a long enough anomaly, DREAM is reached."""
    gate = DreamGate(config=CFG)
    for v in stable_signal(n=50):
        gate.tick(v)
    states = [gate.tick(v).state for v in sustained_anomaly(n=60)]
    assert DREAM in states, f"States seen: {set(states)}"

def test_transient_spike_does_not_trigger_dream():
    gate = DreamGate(config=CFG)
    for v in stable_signal(n=50):
        gate.tick(v)
    gate.tick(5.0)
    gate.tick(-5.0)
    for v in stable_signal(n=20, seed=77):
        gate.tick(v)
    assert gate.state != DREAM

def test_dream_exits_after_stable_period():
    """After DREAM, long stable signal returns to NORMAL."""
    gate = DreamGate(config=CFG)
    for v in stable_signal(n=50):
        gate.tick(v)
    # Drive into DREAM
    for v in sustained_anomaly(n=60):
        gate.tick(v)
    # Some DREAM ticks were reached (verified by test above)
    # Now return to stable — predictor catches up, h drops
    for v in stable_signal(n=150, seed=55):
        gate.tick(v)
    assert gate.state == NORMAL


# ── GateResult ────────────────────────────────────────────────────────────────

def test_result_has_all_fields():
    r = DreamGate(config=CFG).tick(1.0)
    for f in ['actual','predicted','err','gamma','h','epsilon_Q',
              'P_err','X_gen','X_mem','gap','regime',
              'delta_tau','clock','state','sustain']:
        assert hasattr(r, f), f"Missing: {f}"

def test_gamma_always_in_range():
    gate = DreamGate(config=CFG)
    for v in stable_signal(n=50) + sustained_anomaly(n=20):
        assert 0.0 <= gate.tick(v).gamma <= 1.0

def test_h_always_nonnegative():
    gate = DreamGate(config=CFG)
    for v in stable_signal(n=50) + sustained_anomaly(n=20):
        assert gate.tick(v).h >= 0.0


# ── Callback ──────────────────────────────────────────────────────────────────

def test_callback_fires_only_in_dream_state():
    states = []
    gate = DreamGate(config=CFG, on_dream=lambda r: states.append(r.state))
    for v in stable_signal(n=50) + sustained_anomaly(n=60):
        gate.tick(v)
    assert all(s == DREAM for s in states)

def test_callback_fires_during_sustained_anomaly():
    fired = []
    gate = DreamGate(config=CFG, on_dream=lambda r: fired.append(1))
    for v in stable_signal(n=50) + sustained_anomaly(n=60):
        gate.tick(v)
    assert len(fired) > 0, "Expected at least one DREAM callback"


# ── Dual channel ──────────────────────────────────────────────────────────────

def test_dual_channel_xgen_in_range():
    gate = DreamGate(config=CFG)
    random.seed(7)
    for i in range(100):
        train = math.sin(i*0.1)*0.5 + random.gauss(0, 0.08)
        held  = math.sin(i*0.1)*0.5 + random.gauss(0, 0.12)
        r = gate.tick(train, held_out=held)
    assert 0.0 <= r.X_gen <= 1.0
    assert 0.0 <= r.X_mem <= 1.0


# ── Reset ─────────────────────────────────────────────────────────────────────

def test_reset_clears_clock():
    gate = DreamGate(config=CFG)
    for v in burst_signal():
        gate.tick(v)
    gate.reset()
    assert gate.clock == 0.0

def test_reset_clears_state():
    gate = DreamGate(config=CFG)
    for v in sustained_anomaly(n=60):
        gate.tick(v)
    gate.reset()
    assert gate.state == NORMAL

def test_after_reset_returns_valid_result():
    gate = DreamGate(config=CFG)
    for v in burst_signal():
        gate.tick(v)
    gate.reset()
    r = gate.tick(0.5)
    assert isinstance(r, GateResult)
    assert r.state == NORMAL
